# Arm Templates For Azure Machine Learning Workspace
ARM template and parameter json files for resources created for machine learning workspace. Includes, 
Azure Machine Learning workspace, Application Insights, Key vault, Log Analytics workspace and a Storage account.
